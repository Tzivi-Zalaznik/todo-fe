import React from "react";
const apiUri = process.env.API_URL;

const Login = () => {
  let loading = false;
  const handleChaange = () => { };
  const handleSubmit = () => { };
  return (
    <div>LOGIN</div>
  );
};

export default Login;
